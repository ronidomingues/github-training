program exemplo_manipula_arquivos
  implicit none
  character(len=100) :: filename
  logical :: existe
  integer :: unit, ierr
  character(len=8) :: date
  character(len=10) :: time
  character(len=5) :: zone
  character(len=200) :: mensagem

  filename = 'resultado_modelo.txt'
  unit = 10

  ! Obter data e hora do sistema
  call date_and_time(date, time, zone)

  ! Montar mensagem com data e hora
  mensagem = 'Fortran escreveu em: '//trim(date)//' '//trim(time)//' zona: '//trim(zone)

  ! Verifica se o arquivo já existe
  inquire(file=filename, exist=existe)

  if (existe) then
    open(unit, file=filename, status='old', position='append', iostat=ierr)
    if (ierr /= 0) then
      print *, 'Erro ao abrir arquivo existente. iostat =', ierr
      stop 1
    end if
    print *, '📄 Arquivo existente — abrindo em modo append...'
  else
    open(unit, file=filename, status='new', iostat=ierr)
    if (ierr /= 0) then
      print *, 'Erro ao criar arquivo. iostat =', ierr
      stop 1
    end if
    print *, '🆕 Arquivo não existia — criando novo arquivo...'
  end if

  ! Escreve a mensagem no arquivo
  write(unit, '(A)') trim(mensagem)
  close(unit)

  print *, '✅ Mensagem gravada em "', trim(filename), '"'
  print *, 'Conteúdo gravado: ', trim(mensagem)
end program exemplo_manipula_arquivos